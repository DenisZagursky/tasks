-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: syte
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `idCategory` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'одежда'),(2,'политика'),(3,'знаменитости'),(4,'информационные технологии');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `idNews` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `text` longtext,
  `idCategory` int(11) DEFAULT NULL,
  `idSubCategory` int(11) DEFAULT NULL,
  PRIMARY KEY (`idNews`),
  KEY `2_idx` (`idCategory`),
  KEY `3_idx` (`idSubCategory`),
  CONSTRAINT `2` FOREIGN KEY (`idCategory`) REFERENCES `category` (`idCategory`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `3` FOREIGN KEY (`idSubCategory`) REFERENCES `subcategory` (`idSubCategory`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Новая коллекция ','someText','someText',1,NULL),(2,'Шапки бренда stussy','someText','someText',1,3),(3,'Военная политика РБ','someText','someText',2,5),(4,'Новые возможности языка Java','someText','someText',4,7),(5,'Новые методы криптографии','someText','someText',4,NULL);
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsreview`
--

DROP TABLE IF EXISTS `newsreview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsreview` (
  `idNews` int(11) NOT NULL,
  `idReview` int(11) NOT NULL,
  PRIMARY KEY (`idNews`,`idReview`),
  KEY `8_idx` (`idReview`),
  CONSTRAINT `7` FOREIGN KEY (`idNews`) REFERENCES `news` (`idNews`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `8` FOREIGN KEY (`idReview`) REFERENCES `review` (`idReview`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsreview`
--

LOCK TABLES `newsreview` WRITE;
/*!40000 ALTER TABLE `newsreview` DISABLE KEYS */;
INSERT INTO `newsreview` VALUES (1,2),(2,2),(2,3),(4,4),(5,4);
/*!40000 ALTER TABLE `newsreview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newstagnews`
--

DROP TABLE IF EXISTS `newstagnews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newstagnews` (
  `idNews` int(11) NOT NULL,
  `idTagNews` int(11) NOT NULL,
  PRIMARY KEY (`idNews`,`idTagNews`),
  KEY `11_idx` (`idTagNews`),
  CONSTRAINT `10` FOREIGN KEY (`idNews`) REFERENCES `news` (`idNews`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `11` FOREIGN KEY (`idTagNews`) REFERENCES `tagnews` (`idTagNews`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newstagnews`
--

LOCK TABLES `newstagnews` WRITE;
/*!40000 ALTER TABLE `newstagnews` DISABLE KEYS */;
INSERT INTO `newstagnews` VALUES (1,1),(2,1),(4,1),(1,2),(5,2),(1,3),(2,3),(1,4),(1,5),(4,5);
/*!40000 ALTER TABLE `newstagnews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `idReview` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `text` longtext,
  `idCategory` int(11) DEFAULT NULL,
  `idSubCategory` int(11) DEFAULT NULL,
  PRIMARY KEY (`idReview`),
  KEY `5_idx` (`idCategory`),
  KEY `6_idx` (`idSubCategory`),
  CONSTRAINT `5` FOREIGN KEY (`idCategory`) REFERENCES `category` (`idCategory`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `6` FOREIGN KEY (`idSubCategory`) REFERENCES `subcategory` (`idSubCategory`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'Обзор на смартфон','someText','someText',4,6),(2,'Обзор на новую коллекцию','someText','someText',1,NULL),(3,'Обзор на обувь stussy','someText','someText',1,1),(4,'Практика по Java','someText','someText',4,7),(5,'Обзор на экономику Польшу','someText','someText',2,NULL);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewtagreview`
--

DROP TABLE IF EXISTS `reviewtagreview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviewtagreview` (
  `idTagReview` int(11) NOT NULL,
  `idReview` int(11) NOT NULL,
  PRIMARY KEY (`idTagReview`,`idReview`),
  KEY `12_idx` (`idReview`),
  CONSTRAINT `20` FOREIGN KEY (`idTagReview`) REFERENCES `tagreview` (`idTagReview`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `25` FOREIGN KEY (`idReview`) REFERENCES `review` (`idReview`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewtagreview`
--

LOCK TABLES `reviewtagreview` WRITE;
/*!40000 ALTER TABLE `reviewtagreview` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviewtagreview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategory`
--

DROP TABLE IF EXISTS `subcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcategory` (
  `idSubCategory` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `idCategory` int(11) DEFAULT NULL,
  PRIMARY KEY (`idSubCategory`),
  KEY `1_idx` (`idCategory`),
  CONSTRAINT `1` FOREIGN KEY (`idCategory`) REFERENCES `category` (`idCategory`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategory`
--

LOCK TABLES `subcategory` WRITE;
/*!40000 ALTER TABLE `subcategory` DISABLE KEYS */;
INSERT INTO `subcategory` VALUES (1,'обувь',1),(2,'верхняя одежда',1),(3,'головные уборы',1),(4,'политика Беларуси',2),(5,'зарубежная Политика',2),(6,'Смартфоны',4),(7,'Языки программирования',4);
/*!40000 ALTER TABLE `subcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagnews`
--

DROP TABLE IF EXISTS `tagnews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagnews` (
  `idTagNews` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idTagNews`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagnews`
--

LOCK TABLES `tagnews` WRITE;
/*!40000 ALTER TABLE `tagnews` DISABLE KEYS */;
INSERT INTO `tagnews` VALUES (1,'1'),(2,'2'),(3,'3'),(4,'4'),(5,'5');
/*!40000 ALTER TABLE `tagnews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tagreview`
--

DROP TABLE IF EXISTS `tagreview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tagreview` (
  `idTagReview` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idTagReview`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagreview`
--

LOCK TABLES `tagreview` WRITE;
/*!40000 ALTER TABLE `tagreview` DISABLE KEYS */;
/*!40000 ALTER TABLE `tagreview` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-02 10:09:07
