use syte;

SET SQL_SAFE_UPDATES = 0;

select category.name,  count(news.idNews)  from news  inner join category on news.idCategory=category.idCategory group by category.idCategory union
select subcategory.name, count(news.idNews)  from news  inner join subcategory on news.idSubCategory=subcategory.idSubCategory group by subcategory.idCategory; 

select  count(review.idReview) from review  left  join newsreview on review.idReview=newsreview.idReview  where newsreview.idNews is null;
 
select newsname from  (select news.name as newsname, count(news.name) as countnews from  news  inner join newsreview on news.idNews=newsreview.idNews) as sd where countnews>='2' ;

select tagnews.name from tagnews inner join newstagnews on tagnews.idTagNews=newstagnews.idTagNews where newstagnews.idNews='2';





delete from category where category.idCategory='1' ;

update review set idSubCategory='2' where idSubCategory='1';
